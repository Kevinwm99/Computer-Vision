1. Total 41 images belonged to 9 kinds.
2. Low to high resolutions
3. Backgrounds and no backgrounds
